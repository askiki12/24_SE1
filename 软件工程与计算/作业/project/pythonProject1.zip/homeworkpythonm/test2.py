def c():
    print(1)
    return False
    
def kiki():
    if c():
        print(2)
    else:
        print(3)
    return 7
