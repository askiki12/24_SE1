public class Solution {
    public String checkOddEven(int number) {
        /** COMPLETE THE FOLLOWING CODE **/
        // if ( ...... ) {
        //     return ......;
        // } else {
        //     return ......;
        // }
	    return null; //Delete this line
    }

    public String returnDayInWord(int dayNumber) {
        /** COMPLETE THE FOLLOWING CODE **/
        // switch ( ...... ) {
        //     case......:
        //         ......;
        // }
	    return null; //Delete this line
    }

    public long factorial(int n){
        //Return the factorial of a positive integer n.
        /** WRITE YOUR CODE HERE **/
        return 0; //Delete this line
    }

    public long extractDigits(int n){
        //Return the product of each digit from the positive integer n.
        /** WRITE YOUR CODE HERE **/
        return 0; //Delete this line
    }

    public int reverseInt(int n){
        //Return the "reverse" of the input integer.
        /** WRITE YOUR CODE HERE **/
        return 0; //Delete this line
    }
}