# hello world
print("Hello world!")
x = 1

# call method
def add(a, b):
    print("call add()")
    return a + b

print(add(1, 2))

for i in range(0, 10):
    print(i)

# splice two string
print("abcdefghijklmnopqrstuvexyz" + '1234567890')
