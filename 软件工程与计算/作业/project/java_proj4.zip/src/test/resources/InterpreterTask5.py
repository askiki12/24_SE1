a = True
b = False
if(a and a):
	print("and")

if(b or a):
	print("or")
