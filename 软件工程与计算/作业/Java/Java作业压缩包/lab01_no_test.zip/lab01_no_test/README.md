# Lab01

## Problem 1: CheckOddEven

Write a program called checkOddEven which returns "Odd Number" if the int variable “number” is odd, or “Even Number” otherwise.

```java
public class Solution {  
    public String checkOddEven(int number) {
        /** COMPLETE THE FOLLOWING CODE **/
        if ( ...... ) {
            return ......;
        } else {
            return ......;
        }
    }
}
```

## Problem 2: ReturnDayInWord

Write a program called PrintDayInWord which returns “Sunday”, “Monday”, ... “Saturday” if the int variable "dayNumber" is 0, 1, ..., 6, respectively.  
Otherwise, it shall print "Not a valid day".

```java
public class Solution {
    public String returnDayInWord(int dayNumber) {
        /** COMPLETE THE FOLLOWING CODE **/
        switch ( ...... ) {
            case......:
                ......;
        }
    }
}
```

## Problem 3: Factorial

Write a function that takes a positive integer n and returns its factorial.
Factorial of a positive integer n is defined as  n! = 1 x 2 x 3 ... n-1 x n

```java
public class Solution{
    //Return the factorial of a positive integer n.
    public long factorial(int n){
    /** WRITE YOUR CODE HERE **/
    
    }
}
```

## Problem 4: ExtractDigits

Write a function called ExtractDigits to extract each digit from an int, in the reverse order. 
Then returns the product of them. For example, if the int is 15423, the output shall be the result of "3 x 2 x 4 x 5 x 1".

```java
public class Solution{
    //Return the product of each digit from the positive integer n.
    public long extractDigits(int n){
        /** WRITE YOUR CODE HERE **/

    }
}
```

## Problem 5: ReverseInt

Write a function that returns the "reverse" of the input integer. 
For examples, the input integer is 12345, then, returns 54321.

```java
public class Solution{
    //Return the "reverse" of the input integer.
    public int reverseInt(int n){
        /** WRITE YOUR CODE HERE **/

    }
}
```
***Note that the input number may end in zero ！！！***