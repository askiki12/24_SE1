import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Solution {
    public boolean strCombination(String longStr, String[] shortStrs) {
        /**
         * example:
         *  input:
         *      123equals123   [123, equals]
         *  output:
         *      true
         * **/
        /** WRITE YOUR CODE HERE **/
        return true; //Delete this line
    }

    public String cardMaster(String cards) {
        // Return the sorted playing cards.
        /**
         * example:
         *  input:
         *      36TA
         *  output:
         *      AT63
         * **/
        /** WRITE YOUR CODE HERE **/
        return null; //Delete this line
    }

    public int[][] TensorUnfold(int[][][] tensor) {
        /**
         * example:
         *  input:
         *   [
         *    [[1, 2, 3],
         *     [4, 5, 6]],
         *    [[7, 8, 9],
         *     [10, 11, 12]]
         *   ]
         *  output:
         *   [[1, 2, 3, 7, 8, 9],
         *    [4, 5, 6, 10, 11, 12]]
         * **/
        /** WRITE YOUR CODE HERE **/
        return null; //Delete this line
    }

    public boolean IPmatch(String IP, String subnet) {
        /** WRITE YOUR CODE HERE **/
        return false; //Delete this line
    }

    public List<String> quordleCheat(List<Character> have, List<Character> haveNot, Map<Integer,Character> rightIn) {
        /**
         * example:
         *  input:
         *   have: [a, f], haveNot: [w, i], rightIn: {(4:r)}
         *  output:
         *   [afear, after, facer, fader, fager, faker, farer, fator, favor, fchar, feuar, flear, Rafer, Safar, safer, sofar, unfar]
         * **/
        /** WRITE YOUR CODE HERE **/
        return null;//Delete this line
    }
}
