def func_mult(theli):
    num = 1
    temlen = len(theli)
    for i in range(1,temlen+1):
        num = i*num
    return num

print(func_mult([1,2,3,4,5]))