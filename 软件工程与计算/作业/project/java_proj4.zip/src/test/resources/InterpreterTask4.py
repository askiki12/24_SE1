n = 0
while n<10:
     n=n+1
     if n==5:
             break
     if n==2:
             continue
     print(n)
