# test
a = b = 1
print(a)
print(b)

