package pers.xia.jpython.object;

public class PyDict extends PyObject
{
    public PyDict()
    {

    }

    public boolean setItem(PyObject key, PyObject value)
    {
        return true;
    }
    
    public PyObject getItem(PyObject key)
    {
        return null;
    }
}
