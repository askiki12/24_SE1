package pers.xia.jpython.interpreter.statement;

import pers.xia.jpython.interpreter.ProgramState;

public class ContinueStatement implements Statement{
    @Override
    public void run(ProgramState programState) {

    }
}
