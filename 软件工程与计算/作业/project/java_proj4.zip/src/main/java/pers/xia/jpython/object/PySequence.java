package pers.xia.jpython.object;

public abstract class PySequence extends PyObject
{

}
