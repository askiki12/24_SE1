package pers.xia.jpython.object;

public class PyDictComm extends PyObject
{ 
    int hash;
    PyObject key;
    PyObject value;
}
