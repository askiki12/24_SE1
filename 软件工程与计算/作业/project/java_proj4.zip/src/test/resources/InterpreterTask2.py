n = 0
a = 1
b = 2
print(b/a)
print(a%b)
print(a//b)
print(b//a)
