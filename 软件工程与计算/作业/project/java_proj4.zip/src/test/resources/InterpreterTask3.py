for i in range(0,10,2):
    print(i)
ß