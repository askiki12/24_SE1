package pers.xia.jpython.object;

public class PyNone extends PyObject
{
    @Override
    public boolean asBoolean() {
        return false;
    }

}
